package example

object Main {
  def main(args: Array[String]): Unit = {
    def printStuff () = {
      var greet:Array[String] = Array("Hello Scala! This is ", "Hola. This is ", "Guten tag. This is ")
      var name:String = "Abcdefg Xyz"
      for(i <- 0 to 2){
        System.out.println(greet(i)+name)
      }
      for(j <- 0 to 2){
        System.out.println(greet(j)+name.reverse)
      }
    }

    printStuff()

  }
}
